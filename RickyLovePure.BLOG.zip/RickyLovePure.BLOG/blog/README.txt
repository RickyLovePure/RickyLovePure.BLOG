It's a practice work.
Writed for my loving Pure.
Ricky
2022/9/26
Learn form joe-blog，MIT.

使用说明：打开public_html文件夹，后点击web.html即可。